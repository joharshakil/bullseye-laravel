<?php $__env->startSection('content'); ?>



    <section class="content-header">
        <h1>
            Documents
            <!--small>it all starts here</small-->
        </h1>
    </section>



    <section class="content">

        <!-- Default box -->
        <div class="box">
            <div class="">
                <div class="row ">
                    <div class="col-md-6">
                        <div class="card text-left">
                            <div class="card-body">
                                <form method="POST" action="<?php echo e(route('file.upload')); ?>" aria-label="<?php echo e(__('Upload')); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <div class="form-group row ">
                                        <label for="title" class="col-sm-4 col-form-label text-md-right"><?php echo e(__('File Upload')); ?></label>
                                        <div class="col-md-6">
                                            <div id="file" class="dropzone"></div>
                                        </div>
                                        <input type="hidden" name="upload_id" id="upload_id">
                                    </div>
                                    <div class="form-group row">
                                        <label for="title" class="col-sm-4 col-form-label text-md-right"><?php echo e(__('Title')); ?></label>
                                        <div class="col-md-6">
                                            <input id="title" type="text" class="form-control<?php echo e($errors->has('title') ? ' is-invalid' : ''); ?>" name="title" value="<?php echo e(old('title')); ?>" required autofocus />
                                            <?php if($errors->has('title')): ?>
                                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('title')); ?></strong>
                                    </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="overview" class="col-sm-4 col-form-label text-md-right"><?php echo e(__('Overview')); ?></label>
                                        <div class="col-md-6">
                                            <textarea id="overview" cols="10" rows="10" class="form-control<?php echo e($errors->has('overview') ? ' is-invalid' : ''); ?>" name="overview" value="<?php echo e(old('overview')); ?>" required autofocus></textarea>
                                            <?php if($errors->has('overview')): ?>
                                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('overview')); ?></strong>
                                    </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    <div class="form-group row mb-0 text-center">
                                        <div class="gap-distance">
                                            <button type="submit" class="btn btn-primary">
                                                <?php echo e(__('Upload')); ?>

                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <!-- /.box -->

    </section>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>


    <script>

        $('.dropdown a.dropdown-toggle').on('click', function () {
            $(this).parent().toggleClass('open')
        });


    </script>

    <script>

        var drop = new Dropzone('#file', {
            maxFiles: 1,
            createImageThumbnails: true,
            addRemoveLinks: true,
            url: "<?php echo e(route('upload')); ?>",
            headers: {
                'X-CSRF-TOKEN': document.head.querySelector('meta[name="csrf-token"]').content
            },
            init: function() {
                this.on("maxfilesexceeded", function(file){
                    alert("No more files please!");
                });
            },
            success:function (data,serverdata) {
              $("#upload_id").val(serverdata.id);
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>