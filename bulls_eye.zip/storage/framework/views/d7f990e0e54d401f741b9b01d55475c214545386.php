<?php $__env->startComponent('mail::message'); ?>

    Hello  <strong> <?php echo e($name); ?> </strong> .
    <br>
    Thank You for registration

    <?php $__env->startComponent('mail::button', ['url' =>  route('login') ]); ?>
        Log in to Dashboard
    <?php echo $__env->renderComponent(); ?>

    Thanks,<br>

    <?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
