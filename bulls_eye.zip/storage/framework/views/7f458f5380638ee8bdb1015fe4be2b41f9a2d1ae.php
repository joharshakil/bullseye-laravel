<?php $__env->startSection('content'); ?>

    <section class="content-header">
        <h1>
            View Employee
            <!--small>it all starts here</small-->
        </h1>
    </section>



    <section class="content">

        

        <?php if(empty($employee)): ?>
            
            <div class="count-plus">
                <p>    NO RESULT FOUND  </p>
            </div>
        <?php else: ?>

        <!-- Default box -->
            <div class="box">
                <table class="table text-center" id="table">

                    <tr class="red">
                        <th>#</th>
                        <th>Title</th>
                        <th>Overview</th>
                        <th>Employee Phone</th>
                    </tr>
                    <div class="box-body">
                        <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($index+1); ?></td>


                                <td><?php echo e($data->employee_Name); ?></td>
                                <td><?php echo e($data->job_type); ?></td>
                                <td><?php echo e($data->phone_number); ?></td>


                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </table>

                <!-- /.box-body -->
            </div>
            <!-- /.box -->
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>