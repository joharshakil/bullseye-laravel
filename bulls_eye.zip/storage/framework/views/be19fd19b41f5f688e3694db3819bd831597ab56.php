<?php $__env->startSection('content'); ?>

    <section class="content-header">
        <h1>
            Projects
            <!--small>it all starts here</small-->
        </h1>
    </section>



    <section class="content">

        <!-- Default box -->
        <div class="box">
            <table class="table text-center" id="table">
                <div class="box-header with-border">
                    GPR SERVICE
                </div>
                <tr class="red">
                    <th>#</th>
                    <th>Name</th>
                    <?php if(\Illuminate\Support\Facades\Auth::id() == 2){ ?>
                    <td>Email</td>
                    <?php } ?>
                    <th>Date</th>
                    <th>Location</th>
                    <th>Service</th>
                    <th>Action</th>
                </tr>
                <div class="box-body">
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($key + 1); ?></td>
                            <td><?php echo e($data->user->name); ?></td>
                            <?php if(\Illuminate\Support\Facades\Auth::id() == 2){ ?>
                            <td><?php echo e($data->email); ?></td>
                            <?php } ?>
                            <td><?php echo e($data['delivery_date']); ?></td>
                            <td><?php echo e($data['country']); ?></td>
                            <td>GPR Service</td>


                            <td><a href="<?php echo e(url("/gpr/{$data['id']}")); ?>" class="btn btn-primary btn-sm">View</a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

            </table>
            <div class="text-center"><?php echo e($projects->links()); ?></div>
            <!-- /.box-body -->
        </div>
        <!-- /.box -->

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>