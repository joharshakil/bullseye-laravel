<?php $__env->startSection('content'); ?>

    <section class="content-header">
        <h1>
            Documents
            <!--small>it all starts here</small-->
        </h1>
    </section>

    <section class="content">

        <!-- Default box -->
        <?php if(count($em) > 0): ?>
            <div class="box">
                <table class="table text-center table-responsive" id="table">
                    <div class="box-header with-border">
                        EM SERVICE
                    </div>
                    <thead>
                    <tr class="red">

                        <th style="width: 10px">#</th>
                        <th style="width: 200px">Name</th>

                        <?php if(\Illuminate\Support\Facades\Auth::id() == 2){ ?>
                        <th style="width: 200px">Email   </th>
                        <?php } ?>

                        <th style="width: 100px">Date</th>
                        <?php if(\Illuminate\Support\Facades\Auth::id() == 2): ?>
                            <th style="width: 100px">Status</th>
                        <?php endif; ?>
                        <th style="width: 200px">Service</th>
                        <th style="width: 200px">File</th>


                    </tr>
                    </thead>
                    <div class="box-body">
                        <tbody>
                        <?php $__currentLoopData = $em; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td style="width: 100px"><?php echo e($key + 1); ?></td>
                                <td style="width: 200px"><?php echo e($data->user->name); ?></td>
                                <?php if(\Illuminate\Support\Facades\Auth::id() == 2){ ?>
                                <td style="width: 200px"><?php echo e($data->email); ?></td>
                                <?php } ?>

                                <td style="width: 100px"> <?php echo e(Carbon\Carbon::parse($data->date)->format('d/m/Y')); ?>  </td>
                                <?php if(\Illuminate\Support\Facades\Auth::id() == 2): ?>

                                    <td style="width: 100px">   <?php echo e($data->status); ?> </td>
                                <?php endif; ?>



                                <td style="width: 150px">EM Service</td>

                                <td class="anchor-show">
                                    <?php if(isset($data->filename)): ?>

                                        <a target="_blank" href=" <?php echo e(asset( 'storage/'.$data->filename)); ?>"><?php echo e(substr($data->filename, 0, 15) . ' '); ?></a>
                                    <?php endif; ?>
                                </td>


                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </div>

                </table>

                <!-- /.box-body -->
            </div>
        <?php endif; ?>

        <?php if(count($cement) > 0): ?>

            <div class="box">
                <table class="table text-center table-responsive" id="table2">
                    <div class="box-header with-border">
                        Cement SERVICE
                    </div>
                    <thead>
                    <tr class="red">
                        <th style="width: 80px">#</th>

                        <th style="width: 150px">Name</th>
                        <?php if(\Illuminate\Support\Facades\Auth::id() == 2){ ?>
                        <th style="width: 200px">Email</th>
                        <?php } ?>
                        <th style="width: 100px">Date</th>
                        <?php if(\Illuminate\Support\Facades\Auth::id() == 2): ?>
                            <th style="width: 100px">Status</th>
                        <?php endif; ?>
                        <th style="width: 100px"> Service</th>
                        <th style="width: 100px">File</th>
                    </tr>
                    </thead>
                    <tbody>
                    <div class="box-body">
                        <?php $__currentLoopData = $cement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>

                                <td style="width: 80px"><?php echo e($key + 1); ?></td>
                                <td style="width: 150px"><?php echo e($data->user->name); ?></th>
                                <?php if(\Illuminate\Support\Facades\Auth::id() == 2){ ?>
                                <td style="width: 200px"><?php echo e($data->email); ?></td>
                                <?php } ?>

                                <td style="width: 100px"> <?php echo e(Carbon\Carbon::parse($data->date)->format('d/m/Y')); ?>  </td>
                                <?php if(\Illuminate\Support\Facades\Auth::id() == 2): ?>

                                    <td style="width: 100px">   <?php echo e($data->status); ?> </td>
                                <?php endif; ?>
                                <td style="width: 100px">  Cement Service </td>

                                <td style="width: 100px">
                                    <?php if(isset($data->filename)): ?>

                                        <a target="_blank" href=" <?php echo e(asset( 'storage/'.$data->filename)); ?>"><?php echo e(substr($data->filename, 0, 15) . ' '); ?></a>
                                    <?php endif; ?>
                                </td>

                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    </tbody>
                </table>

                <!-- /.box-body -->
            </div>
        <?php endif; ?>

        <?php if(count($gpr) > 0): ?>

            <div class="box">
                <table class="table text-center table-responsive" id="table3">
                    <div class="box-header with-border">
                        GPR SERVICE
                    </div>
                    <thead>
                    <tr class="red">
                        <th style="width: 80px">#</th>
                        <th style="width: 150px">Name</th>
                        <?php if(\Illuminate\Support\Facades\Auth::id() == 2){ ?>
                        <th style="width: 200px">Email</th>
                        <?php } ?>
                        <th style="width: 200px">Date</th>
                        <?php if(\Illuminate\Support\Facades\Auth::id() == 2): ?>
                            <th style="width: 100px">Status</th>
                        <?php endif; ?>
                        <th style="width: 150px">Service</th>
                        <th style="width: 100px">File</th>
                    </tr>
                    </thead>
                    <tbody>
                    <div class="box-body">
                        <?php $__currentLoopData = $gpr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>

                                <td style="width: 80px"><?php echo e($key + 1); ?></td>
                                <td style="width: 150px"><?php echo e($data->user->name); ?></th>
                                <?php if(\Illuminate\Support\Facades\Auth::id() == 2){ ?>
                                <td style="width: 200px"><?php echo e($data->email); ?></td>
                                <?php } ?>

                                <td style="width: 100px"> <?php echo e(Carbon\Carbon::parse($data->date)->format('d/m/Y')); ?>  </td>
                                <?php if(\Illuminate\Support\Facades\Auth::id() == 2): ?>

                                    <td style="width: 100px">   <?php echo e($data->status); ?> </td>
                                <?php endif; ?>

                                <td style="width: 100px">   GPR Service </td>

                                <td style="width: 100px">
                                    <?php if(isset($data->filename)): ?>

                                        <a target="_blank" href=" <?php echo e(asset( 'storage/'.$data->filename)); ?>"><?php echo e(substr($data->filename, 0, 15) . ' '); ?></a>
                                    <?php endif; ?>
                                </td>

                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    </tbody>
                </table>

                <!-- /.box-body -->
            </div>
        <?php endif; ?>

        <?php if(count($em) == 0  && count($cement) == 0 && count($gpr) == 0  ): ?>

            <p>    NO RESULT FOUND  </p>

    <?php endif; ?>


    <!-- /.box -->

    </section>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>