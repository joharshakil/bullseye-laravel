<?php $__env->startSection('content'); ?>

    <section class="content-header">
        <h1>
            Project Details
            <!--small>it all starts here</small-->
        </h1>
    </section>



    <section class="content">

        <!-- Default box -->
        <?php if(count($em) > 0): ?>
            <div class="box">
                <table class="table text-center" id="table">
                    <div class="box-header with-border">
                        EM SERVICE
                    </div>
                    <thead>
                    <tr class="red">
                        <th style="width: 100px">#</th>
                        <?php if(\Illuminate\Support\Facades\Auth::id() == 2){ ?>
                        <td>Email</td>
                        <?php } ?>
                        <th style="width: 200px">Date</th>
                        <th style="width: 200px">Status</th>
                        <th style="width: 200px">Schedule Time</th>
                        <th style="width: 300px">Location</th>

                        <th style="width: 200px">Service</th>
                        <th style="width: 150px">Actions</th>
                    </tr>
                    </thead>
                    <div class="box-body">
                        <tbody>
                        <?php $__currentLoopData = $em; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td style="width: 100px"><?php echo e($key + 1); ?></td>

                                <?php if(\Illuminate\Support\Facades\Auth::id() == 2){ ?>
                                <td style="width: 200px"><?php echo e($data->email); ?></td>
                                <?php } ?>
                                <td style="width: 300px"> <?php echo e(Carbon\Carbon::parse($data->date)->format('d/m/Y')); ?>  </td>
                                <td style="width: 150px"><?php echo e($data['status']); ?></td>
                                <td style="width: 150px"><?php echo e($data['starttime']); ?></td>
                                <td style="width: 200px"><?php echo e($data['country']); ?> </td>
                                <td style="width: 150px">EM Service</td>


                                <td>
                                    <a href="<?php echo e(url("/es/cancel/{$data['id']}")); ?>" class="btn btn-primary btn-sm">Cancel</a>


                                    <a href="<?php echo e(url("/es/edit/{$data['id']}")); ?>" class="btn btn-primary btn-sm">Edit</a>

                                    <a href="<?php echo e(url("/es/{$data['id']}")); ?>" class="btn btn-primary btn-sm">View</a>



                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </div>

                </table>
                <div class="text-center"><?php echo e($em->links()); ?></div>
                <!-- /.box-body -->
            </div>
        <?php endif; ?>

        <?php if(count($cement) > 0): ?>

            <div class="box">
                <table class="table text-center" id="table1">
                    <div class="box-header with-border">
                        Cement SERVICE
                    </div>
                    <thead>
                    <tr class="red">
                        <th style="width: 80px">#</th>
                        <?php if(\Illuminate\Support\Facades\Auth::id() == 2){ ?>
                        <td style="width: 200px">Email</td>
                        <?php } ?>
                        <th style="width: 200px">Date</th>
                        <th style="width: 200px">Status</th>
                        <th style="width: 200px">Schedule Time</th>
                        <th style="width: 200px">markings</th>
                        <th style="width: 150px">Location</th>
                        <th style="width: 100px">Actions</th>
                    </tr>
                    </thead>
                    <div class="box-body">
                        <?php $__currentLoopData = $cement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td style="width: 80px"><?php echo e($key + 1); ?></td>

                                <?php if(\Illuminate\Support\Facades\Auth::id() == 2){ ?>
                                <td style="width: 200px"><?php echo e($data->email); ?></td>
                                <?php } ?>
                                <td style="width: 200px"><?php echo e(Carbon\Carbon::parse($data->delivery_date)->format('d/m/Y')); ?>  </td>
                                <td style="width: 150px"><?php echo e($data['status']); ?></td>
                                <td style="width: 150px"><?php echo e($data['starttime']); ?></td>
                                <td style="width: 200px"><?php echo e($data['marking']); ?></td>
                                <td style="width: 150px"><?php echo e($data['country']); ?></td>
                                
                                <td style="width: 100px">
                                    <a href="<?php echo e(url("/cement/cancel/{$data['id']}")); ?>" class="btn btn-primary btn-sm">Cancel</a>
                                    <a href="<?php echo e(url("/cement/edit/{$data['id']}")); ?>" class="btn btn-primary btn-sm">Edit</a>
                                    <a href="<?php echo e(url("/cement/{$data['id']}")); ?>" class="btn btn-primary btn-sm">View</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </table>
                <div class="text-center"><?php echo e($cement->links()); ?></div>
                <!-- /.box-body -->
            </div>
        <?php endif; ?>

        <?php if(count($gpr) > 0): ?>

            <div class="box">
                <table class="table text-center" id="table2">
                    <div class="box-header with-border">
                        GPR SERVICE
                    </div>
                    <thead>
                    <tr class="red">
                        <th style="width: 80px">#</th>
                        <?php if(\Illuminate\Support\Facades\Auth::id() == 2){ ?>
                        <td style="width: 200px">Email</td>
                        <?php } ?>
                        <th style="width: 200px">Date</th>
                        <th style="width: 200px">Status</th>
                        <th style="width: 200px">Schedule Time</th>
                        <th style="width: 200px">markings</th>
                        <th style="width: 150px">Location</th>
                        <th style="width: 100px">Actions</th>
                    </tr>
                    </thead>
                    <div class="box-body">
                        <tbody>
                        <?php $__currentLoopData = $gpr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td style="width: 80px"><?php echo e($key + 1); ?></td>

                                <?php if(\Illuminate\Support\Facades\Auth::id() == 2){ ?>
                                <td style="width: 200px"><?php echo e($data->email); ?></td>
                                <?php } ?>
                                <td style="width: 200px"><?php echo e(Carbon\Carbon::parse($data->delivery_date)->format('d/m/Y')); ?></td>
                                <td style="width: 150px"><?php echo e($data['status']); ?></td>
                                <td style="width: 150px"><?php echo e($data['starttime']); ?></td>
                                <td style="width: 150px"><?php echo e($data['marking']); ?></td>
                                <td style="width: 150px"><?php echo e($data['country']); ?></td>


                                <td style="width: 100px">
                                    <a href="<?php echo e(url("/gpr/cancel/{$data['id']}")); ?>" class="btn btn-primary btn-sm">Cancel</a>
                                    <a href="<?php echo e(url("/gpr/edit/{$data['id']}")); ?>" class="btn btn-primary btn-sm">Edit</a>
                                    <a href="<?php echo e(url("/gpr/{$data['id']}")); ?>" class="btn btn-primary btn-sm">View</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </div>

                </table>
                <div class="text-center"><?php echo e($gpr->links()); ?></div>
                <!-- /.box-body -->
            </div>
        <?php endif; ?>

        <?php if(count($em) == 0  && count($cement) == 0 && count($gpr) == 0   ): ?>

            <p>    NO RESULT FOUND  </p>

    <?php endif; ?>


    <!-- /.box -->

    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script>
    /*   $("#delete").on("click", function(){
           return alert("Are you sure?");
       });*/
    $(document).ready(function() {
        $('#table').DataTable();
    });

    $(document).ready(function() {
        $('#table1').DataTable();
    });
    $(document).ready(function() {
        $('#table2').DataTable();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>