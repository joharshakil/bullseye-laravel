<?php $__env->startSection('content'); ?>

    <section class="content-header">
        <h1>
            Invoices
            <!--small>it all starts here</small-->
        </h1>
    </section>



    <section class="content">



        <?php if(empty($invoices)): ?>
            <div class="count-plus">
                <p>    NO RESULT FOUND  </p>
            </div>
        <?php else: ?>


        <!-- Default box -->
            <div class="box">
                <table class="table text-center" id="table">
                    <div class="box-header with-border">

                    </div>
                    <tr class="red">
                        <th>#</th>
                        <th>Company Name </th>
                        <th>Service Name</th>
                        <th>Project Address </th>
                        <th>Amount</th>
                        <th>Payment Status</th>
                        <th>Actions</th>
                    </tr>

                    <div class="box-body">
                        <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                            <tr>
                                <td><?php echo e($key + 1); ?></td>
                                <td>
                                    <?php if(isset($data['company_name'])): ?>
                                        <?php echo e($data['company_name']); ?>

                                    <?php endif; ?>
                                </td>
                                <td><?=str_replace('_', ' ', $data['service_title'])?>  </td>



                                <td><?php echo e($data['country']); ?> </td>

                                <td>$ <?php echo e($data['price']); ?></td>
                                <td><?php echo e($data['payment_status']); ?></td>


                                <td><a href="<?php echo e(url("/invoice/{$data['id']}")); ?>" class="btn btn-primary btn-sm">View</a></td>
                            </tr>


                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </table>
            
            <!-- /.box-body -->
            </div>
            <!-- /.box -->
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>