<?php $__env->startSection('content'); ?>
    <section class="content">

        <!-- Default box -->
        <div class="box">

            <div class="box-header with-border">
                <h3 class="page-title">
                    <?php echo app('translator')->getFromJson('quickadmin.appointments.title'); ?>
                </h3>
            </div>
            <?php if(\Illuminate\Support\Facades\Auth::id() == 2): ?>
            <div class="col-md-6 section-block">
                <ul>
                   <li> <a href="<?php echo e(route('es')); ?>" target="_blank" class="btn btn-xs btn-primary"> EM  SERVICE</a></li>
                    <li>  <a href="<?php echo e(route('cement')); ?>" target="_blank" class="btn btn-xs btn-primary"> CEMENT SERVICE</a>   </li>
                    <li>  <a href="<?php echo e(route('gpr')); ?>" target="_blank" class="btn btn-xs btn-primary"> GPR SERVICE</a>   </li>
                </ul>

            </div>
            <?php endif; ?>

            <p>
                

            </p>


            <div id='calendar'></div>

            <br/>

            <div class="panel panel-default">
                <div class="panel-heading">
                    <?php echo app('translator')->getFromJson('quickadmin.qa_list'); ?>
                </div>

                

                <section class="content">

                    <!-- Default box -->
                    <?php if(count($em) > 0): ?>
                        <div class="box">
                            <table class="table text-center table-responsive" id="table">
                                <div class="box-header with-border">
                                    EM SERVICE
                                </div>
                                <thead>
                                <tr class="red">

                                    <th style="width: 10px">#</th>
                                    <th style="width: 100px">Name</th>
                                    <?php if(\Illuminate\Support\Facades\Auth::id() == 2){ ?>
                                    <th tyle="width: 200px">Email</th>
                                    <?php } ?>

                                    <th style="width: 100px">Date</th>
                                    <th style="width: 100px">Employee Assign</th>
                                    <th style="width: 100px">Status</th>
                                    <th style="width: 300px">Location</th>

                                    <th style="width: 200px">Service</th>
                                    <th style="width: 150px">Actions</th>

                                </tr>
                                </thead>
                                <div class="box-body">
                                    <tbody>
                                    <?php $__currentLoopData = $em; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($data->status != "completed"): ?>
                                        <tr>


                                            <td style="width: 100px"><?php echo e($key + 1); ?></td>
                                            <td style="width: 100px"><?php echo e($data->user->name); ?></th>
                                            <?php if(\Illuminate\Support\Facades\Auth::id() == 2){ ?>
                                            <td style="width: 200px"><?php echo e($data->email); ?></td>
                                            <?php } ?>

                                            <td style="width: 100px"> <?php echo e(Carbon\Carbon::parse($data->date)->format('d/m/Y')); ?>  </td>
                                            <?php if(\Illuminate\Support\Facades\Auth::id() == 2): ?>
                                                <td style="width: 100px">   <?php echo e(isset($data->employee) ? $data->employee->employee_Name : ""); ?> </td>
                                                <td style="width: 100px">   <?php echo e($data->status); ?> </td>
                                            <?php endif; ?>

                                            <td style="width: 200px"><?php echo e($data->country); ?></td>

                                            <td style="width: 150px">EM Service</td>
                                            <td>
                                                <a href="<?php echo e(url("/es/edit/{$data->id}")); ?>" class="btn btn-xs btn-primary">Edit</a>
                                                <a href="<?php echo e(url("/es/{$data->id}")); ?>" class="btn btn-xs btn-primary">View</a>
                                                <a href="<?php echo e(url("/es/delete/{$data->id}")); ?>" class="btn btn-xs btn-primary " id="delete" name="_method" onclick="return confirm('Are you sure to delete this ?')">Delete</a>
                                                <a href="<?php echo e(url("/es/cancel/{$data->id}")); ?>" class="btn btn-xs btn-primary">Cancel</a>
                                            </td>

                                        </tr>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </div>

                            </table>

                            <!-- /.box-body -->
                        </div>
                    <?php endif; ?>

                    <?php if(count($cement) > 0): ?>

                        <div class="box">
                            <table class="table text-center table-responsive" id="table2">
                                <div class="box-header with-border">
                                    Cement SERVICE
                                </div>
                                <thead>
                                <tr class="red">
                                    <th style="width: 80px">#</th>

                                    <th style="width: 100px">Name</th>
                                    <?php if(\Illuminate\Support\Facades\Auth::id() == 2){ ?>
                                    <th style="width: 200px">Email</th>
                                    <?php } ?>
                                    <th style="width: 100px">Date</th>
                                    <th style="width: 100px">Employee Assign</th>
                                    <th style="width: 100px">Status</th>
                                    <th style="width: 100px">markings</th>
                                    <th style="width: 150px">Location</th>
                                    <th style="width: 100px">Actions</th>
                                </tr>
                                </thead>
                                <tbody>
                                <div class="box-body">
                                    <?php $__currentLoopData = $cement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($data->status != "completed"): ?>
                                        <tr>

                                            <td style="width: 80px"><?php echo e($key + 1); ?></td>
                                            <td style="width: 100px"><?php echo e($data->user->name); ?></th>
                                            <?php if(\Illuminate\Support\Facades\Auth::id() == 2){ ?>
                                            <td style="width: 200px"><?php echo e($data->email); ?></td>
                                            <?php } ?>

                                            <td style="width: 100px"> <?php echo e(Carbon\Carbon::parse($data->date)->format('d/m/Y')); ?>  </td>
                                            <?php if(\Illuminate\Support\Facades\Auth::id() == 2): ?>
                                                <td style="width: 100px">   <?php echo e(isset($data->employee) ? $data->employee->employee_Name : ""); ?> </td>
                                                    <td style="width: 100px">   <?php echo e($data->status); ?> </td>
                                                <?php endif; ?>

                                            <td style="width: 100px"><?php echo e($data['marking']); ?></td>
                                            <td style="width: 150px"><?php echo e($data['country']); ?></td>
                                            
                                            <td style="width: 100px">
                                                <a href="<?php echo e(url("/cement/cancel/{$data['id']}")); ?>" class="btn btn-xs btn-primary">Cancel</a>
                                                <a href="<?php echo e(url("/cement/edit/{$data['id']}")); ?>" class="btn btn-xs btn-primary">Edit</a>
                                                <a href="<?php echo e(url("/cement/delete/{$data->id}")); ?>" class="btn btn-xs btn-primary " id="delete" name="_method" onclick="return confirm('Are you sure to delete this ?')">Delete</a>
                                                <a href="<?php echo e(url("/cement/{$data['id']}")); ?>" class="btn btn-xs btn-primary">View</a>
                                            </td>

                                        </tr>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                </tbody>
                            </table>

                            <!-- /.box-body -->
                        </div>
                    <?php endif; ?>

                    <?php if(count($gpr) > 0): ?>

                        <div class="box">
                            <table class="table text-center table-responsive" id="table3">
                                <div class="box-header with-border">
                                    GPR SERVICE
                                </div>
                                <thead>
                                <tr class="red">
                                    <th style="width: 20px">#</th>
                                    <th style="width: 100px">Name</th>
                                    <?php if(\Illuminate\Support\Facades\Auth::id() == 2){ ?>
                                    <th style="width: 200px">Email</th>
                                    <?php } ?>
                                    <th style="width: 100px">Date</th>
                                    <th style="width: 100px">Employee Assign</th>
                                    <th style="width: 100px">Status</th>
                                    <th style="width: 100px">markings</th>
                                    <th style="width: 150px">Location</th>
                                    <th style="width: 100px">Actions</th>
                                </tr>
                                </thead>

                                <div class="box-body">
                                    <tbody>

                                    <?php $__currentLoopData = $gpr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($data->status != "completed"): ?>
                                        <tr>

                                            <td style="width: 80px"><?php echo e($key + 1); ?></td>
                                            <td style="width: 100px"><?php echo e($data->user->name); ?></th>
                                            <?php if(\Illuminate\Support\Facades\Auth::id() == 2){ ?>
                                            <td style="width: 200px"><?php echo e($data->email); ?></td>
                                            <?php } ?>

                                            <td style="width: 100px"> <?php echo e(Carbon\Carbon::parse($data->date)->format('d/m/Y')); ?>  </td>
                                            <?php if(\Illuminate\Support\Facades\Auth::id() == 2): ?>
                                                <td style="width: 100px">   <?php echo e(isset($data->employee) ? $data->employee->employee_Name : ""); ?> </td>
                                                    <td style="width: 100px">   <?php echo e($data->status); ?> </td>
                                            <?php endif; ?>
                                            <td style="width: 100px"><?php echo e($data['marking']); ?></td>
                                            <td style="width: 150px"><?php echo e($data['country']); ?></td>


                                            <td style="width: 100px">
                                                <a href="<?php echo e(url("/gpr/cancel/{$data['id']}")); ?>" class="btn btn-xs btn-primary">Cancel</a>
                                                <a href="<?php echo e(url("/gpr/edit/{$data['id']}")); ?>" class="btn btn-xs btn-primary">Edit</a>
                                                <a href="<?php echo e(url("/gpr/delete/{$data->id}")); ?>" class="btn btn-xs btn-primary " id="delete" name="_method" onclick="return confirm('Are you sure to delete this ?')">Delete</a>
                                                <a href="<?php echo e(url("/gpr/{$data['id']}")); ?>" class="btn btn-xs btn-primary">View</a></td>

                                        </tr>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </div>

                            </table>

                            <!-- /.box-body -->
                        </div>
                    <?php endif; ?>

                    <?php if(count($em) == 0  && count($cement) == 0 && count($gpr) == 0   ): ?>

                        <p>    NO RESULT FOUND  </p>

                <?php endif; ?>


                <!-- /.box -->

                </section>

            </div>
        </div>

        <!-- /.box -->

    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>

    <script src="<?php echo e(asset('https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap.min.js')); ?>"></script>

  
  <script>
   /*   $("#delete").on("click", function(){
          return alert("Are you sure?");
      });*/
      $(document).ready(function() {
          $('#table').DataTable();
      });

      $(document).ready(function() {
          $('#table1').DataTable();
      });
      $(document).ready(function() {
          $('#table2').DataTable();
      });
   $(document).ready(function() {
       $('#table3').DataTable();
   });
  </script>

    <script>


        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('appointment_delete')): ?>
            window.route_mass_crud_entries_destroy = '<?php echo e(route('admin.appointments.mass_destroy')); ?>';
        <?php endif; ?>

    </script>
    <script>
        $(document).ready(function () {
            // page is now ready, initialize the calendar...
            $('#calendar').fullCalendar({
                // put your options and callbacks here
                defaultView: 'agendaWeek',
                events: [
                        <?php $__currentLoopData = $em; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    {

                        title: '<?php echo e($appointment->name." ".$appointment->email); ?>',
                        <?php if($appointment->starttime): ?>
                        start: '<?php echo e($appointment->starttime); ?>',
                        <?php else: ?>
                        start: '<?php echo e($appointment->date); ?>',
                        <?php endif; ?>
                                <?php if($appointment->endtime): ?>
                        end: '<?php echo e($appointment->endtime); ?>',
                        <?php else: ?>
                        end: '<?php echo e($appointment->date); ?>',
                        <?php endif; ?>
                        url: '<?php echo e(url('/es/edit', $appointment->id)); ?>'
                    },
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $gpr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    {
                        title: '<?php echo e($appointment->name." ".$appointment->email); ?>',
                        <?php if($appointment->starttime): ?>
                        start: '<?php echo e($appointment->starttime); ?>',
                        <?php else: ?>
                        start: '<?php echo e($appointment->delivery_date); ?>',
                        <?php endif; ?>
                                <?php if($appointment->endtime): ?>
                        end: '<?php echo e($appointment->endtime); ?>',
                        <?php else: ?>
                        end: '<?php echo e($appointment->delivery_date); ?>',
                        <?php endif; ?>
                        url: '<?php echo e(url('/gpr/edit', $appointment->id)); ?>'
                    },
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $cement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    {
                        title: '<?php echo e($appointment->name." ".$appointment->email); ?>',
                        <?php if($appointment->starttime): ?>
                        start: '<?php echo e($appointment->starttime); ?>',
                        <?php else: ?>
                        start: '<?php echo e($appointment->delivery_date); ?>',
                        <?php endif; ?>
                                <?php if($appointment->endtime): ?>
                        end: '<?php echo e($appointment->endtime); ?>',
                        <?php else: ?>
                        end: '<?php echo e($appointment->delivery_date); ?>',
                        <?php endif; ?>

                        url: '<?php echo e(url('/cement/edit', $appointment->id)); ?>'
                    },
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                ]
            })
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>