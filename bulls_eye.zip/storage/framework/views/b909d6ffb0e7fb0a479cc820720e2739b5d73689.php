<?php $__env->startSection('content'); ?>


    <!-- Content Wrapper. Contains page content -->
    
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Dashboard
            <small>Control panel</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
        </ol>
    </section>


    <?php if(Auth::id() == 2): ?>
        <!-- Main content -->
    <section class="content">
        <!-- Small boxes (Stat box) -->
        <div class="row">
            <div class="col-lg-2 col-xs-6">
                <!-- small box -->
                <div class="small-box bg-aqua">
                    <div class="inner">
                        <h3><?php echo e($invoiceCount); ?></h3>

                        <p>Invoices</p>
                    </div>
                    <div class="icon">
                        <i class="ion  ion-cash"></i>
                    </div>
                    <a href="<?php echo e(url('/')); ?>/invoice" class="small-box-footer" target="-blank">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <!-- ./col -->
        
            <!-- ./col -->
            <div class="col-lg-2 col-xs-6">
                <!-- small box -->
                <div class="small-box bg-yellow">
                    <div class="inner">
                        <h3>  <?php echo e($userCount); ?> </h3>

                        <p>User Registrations</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-person-add"></i>
                    </div>
                    <a href="<?php echo e(url('/')); ?>/users" class="small-box-footer" target="-blank">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <!-- ./col -->

            <div class="col-lg-2 col-xs-6">
                <!-- small box -->
                <div class="small-box bg-red">


                    <div class="inner ">
                        <h3> <?php echo e($emServiceCount); ?> </h3>
                        <p>EM Services</p>


                    </div>

                    <div class="icon">
                        <i class="ion ion-pie-graph"></i>

                    </div>
                    <a href="<?php echo e(url('/')); ?>/user_projects" class="small-box-footer" target="-blank">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>



            </div>

            <div class="col-lg-2 col-xs-6">
                <!-- small box -->
                <div class="small-box bg-red">


                    <div class="inner">
                        <h3> <?php echo e($gprServiceCount); ?> </h3>
                        <p>GPR Services</p>


                    </div>

                    <div class="icon">
                        <i class="ion ion-pie-graph"></i>

                    </div>
                    <a href="<?php echo e(url('/')); ?>/gpr_projects" class="small-box-footer" target="-blank">More info <i class="fa fa-arrow-circle-right"></i></a>


                </div>



            </div>


            <div class="col-lg-2 col-xs-6">
                <!-- small box -->
                <div class="small-box bg-red">


                    <div class="inner ">
                        <h3> <?php echo e($cementServiceCount); ?> </h3>
                        <p>CEMENT Services</p>


                    </div>

                    <div class="icon">
                        <i class="ion ion-pie-graph"></i>

                    </div>
                    <a href="<?php echo e(url('/')); ?>/cement_projects" class="small-box-footer" target="-blank">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>



            </div>




            <!-- ./col -->
        </div>

        <div class="box">
            <table class="table text-center table-responsive" id="table2">
                <div class="box-header with-border">
                    COMMENTS
                </div>
                <thead>
                <tr class="red">
                    <th style="width: 100px">Comment</th>
                    <th style="width: 100px">User</th>
                    <th style="width: 100px">Project Type</th>
                    <th style="width: 100px">Actions</th>
                </tr>
                </thead>
                <tbody>
                <div class="box-body">
                    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>

                                <td style="width: 100px"><?php echo e($data->body); ?></td>
                                <td style="width: 100px"><?php echo e($data->user->name); ?></th>
                                <td style="width: 100px">
                                    <?php if($data->em_id): ?>
                                        EM Service
                                    <?php endif; ?>
                                    <?php if($data->gpr_id): ?>
                                      GPR Service
                                    <?php endif; ?>
                                    <?php if($data->cement_id): ?>
                                        Cement Service
                                    <?php endif; ?>
                                </td>
                                <?php if($data->em_id): ?>
                                <td style="width: 100px">
                                    <a href="<?php echo e(url("/es/".$data['id'])); ?>" class="btn btn-xs btn-primary">Reply</a>
                                </td>
                                <?php endif; ?>
                                <?php if($data->gpr_id): ?>
                                    <td style="width: 100px">
                                        <a href="<?php echo e(url("/gpr/".$data['id'])); ?>" class="btn btn-xs btn-primary">Reply</a>
                                    </td>
                                <?php endif; ?>
                                <?php if($data->cement_id): ?>
                                    <td style="width: 100px">
                                        <a href="<?php echo e(url("/cement/".$data['id'])); ?>" class="btn btn-xs btn-primary">Reply</a>
                                    </td>
                                <?php endif; ?>
                            </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                </tbody>
            </table>

            <!-- /.box-body -->
        </div>

        <div id='calendar'></div>
        <!-- /.row -->
        <!-- Main row -->
        <div class="row">
            <!-- Left col -->
            <section class="col-lg-7 connectedSortable">
                <!-- Custom tabs (Charts with tabs)-->
            
            <!-- /.nav-tabs-custom -->

                <!-- Chat box -->
            
            <!-- /.box (chat box) -->

                <!-- TO DO List -->

                <!-- /.box -->

                <!-- quick email widget -->
                

            </section>
            <!-- /.Left col -->
            <!-- right col (We are only adding the ID to make the widgets sortable)-->

            <!-- right col -->
        </div>
        <!-- /.row (main row) -->

    </section>
    <!-- /.content -->
    <?php else: ?>
    
    <!-- /.content-wrapper -->

    <section class="content">
        <!-- Small boxes (Stat box) -->
        <div class="row">
            <div class="col-lg-2 col-xs-6">
                <!-- small box -->
                <div class="small-box bg-aqua">
                    <div class="inner">
                        <h3> <?php echo e($totalServices); ?></h3>

                        <p>Invoices</p>
                    </div>
                    <div class="icon">
                        <i class="ion  ion-cash"></i>
                    </div>
                    <a href="<?php echo e(url('/')); ?>/invoice" class="small-box-footer" target="-blank">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <!-- ./col -->
           
            <!-- ./col -->


            <div class="col-lg-2 col-xs-6">
                <!-- small box -->
                <div class="small-box bg-red">


                    <div class="inner ">
                        <h3> <?php echo e($totalServices); ?> </h3>
                        <p>Services</p>


                    </div>

                    <div class="icon">
                        <i class="ion ion-pie-graph"></i>

                    </div>
                    <a href="<?php echo e(url('/')); ?>/user_projects" class="small-box-footer" target="-blank">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>



            </div>


            <div class="col-lg-2 col-xs-6">
                <!-- small box -->
                <div class="small-box bg-yellow">
                    <div class="inner">
                        <h3>  <?php echo e($totalServices); ?> </h3>

                        <p>Projects</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-person-add"></i>
                    </div>
                    <a href="<?php echo e(url('/')); ?>/user_projects" class="small-box-footer" target="-blank">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>





            <!-- ./col -->
        </div>
        <!-- /.row -->
        <!-- Main row -->
        <div class="row">
            <!-- Left col -->
            <section class="col-lg-7 connectedSortable">
                <!-- Custom tabs (Charts with tabs)-->
            
            <!-- /.nav-tabs-custom -->

                <!-- Chat box -->
            
            <!-- /.box (chat box) -->

                <!-- TO DO List -->

                <!-- /.box -->

                <!-- quick email widget -->
                

            </section>
            <!-- /.Left col -->
            <!-- right col (We are only adding the ID to make the widgets sortable)-->

            <!-- right col -->
        </div>
        <!-- /.row (main row) -->

    </section>

    <?php endif; ?>

    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 admin-dashborad" style="display: flex; justify-content: center; align-items: center; min-height: 420px;flex-direction: column; text-align: center;">



                <div class="col-md-10">

                    
                </div>

                <div class="panel panel-default">
                    
                    <?php if(isset($code)){?>
                    <div class="alert alert-<?php echo e($code); ?>">
                        <strong><?php echo e($code); ?>!</strong> <?php echo e($message); ?>

                    </div>
                    <?php } ?>
                    
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
<?php if(Auth::id() == 2): ?>
<script>
    $(document).ready(function () {
        // page is now ready, initialize the calendar...
        $('#calendar').fullCalendar({
            // put your options and callbacks here
            defaultView: 'agendaWeek',
            events: [
                    <?php $__currentLoopData = $em; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                {
                    title: '<?php echo e($appointment->name." ".$appointment->email); ?>',
                    <?php if($appointment->starttime): ?>
                    start: '<?php echo e($appointment->starttime); ?>',
                    <?php else: ?>
                    start: '<?php echo e($appointment->date); ?>',
                    <?php endif; ?>
                            <?php if($appointment->endtime): ?>
                    end: '<?php echo e($appointment->endtime); ?>',
                    <?php else: ?>
                    end: '<?php echo e($appointment->date); ?>',
                    <?php endif; ?>
                    url: '<?php echo e(url('/es/edit', $appointment->id)); ?>'
                },
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $gpr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                {
                    title: '<?php echo e($appointment->name." ".$appointment->email); ?>',
                    <?php if($appointment->starttime): ?>
                    start: '<?php echo e($appointment->starttime); ?>',
                    <?php else: ?>
                    start: '<?php echo e($appointment->delivery_date); ?>',
                    <?php endif; ?>
                            <?php if($appointment->endtime): ?>
                    end: '<?php echo e($appointment->endtime); ?>',
                    <?php else: ?>
                    end: '<?php echo e($appointment->delivery_date); ?>',
                    <?php endif; ?>
                    url: '<?php echo e(url('/gpr/edit', $appointment->id)); ?>'
                },
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $cement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                {
                    title: '<?php echo e($appointment->name." ".$appointment->email); ?>',
                    <?php if($appointment->starttime): ?>
                    start: '<?php echo e($appointment->starttime); ?>',
                    <?php else: ?>
                    start: '<?php echo e($appointment->delivery_date); ?>',
                    <?php endif; ?>
                            <?php if($appointment->endtime): ?>
                    end: '<?php echo e($appointment->endtime); ?>',
                    <?php else: ?>
                    end: '<?php echo e($appointment->delivery_date); ?>',
                    <?php endif; ?>

                    url: '<?php echo e(url('/cement/edit', $appointment->id)); ?>'
                },
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            ]
        })
    });
</script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>