<?php $__env->startSection('content'); ?>

    <section class="content-header">
        <h1>
           Users
            <!--small>it all starts here</small-->
        </h1>
    </section>



<section class="content">

    <!-- Default box -->
    <div class="box">
        <div class="box-header with-border">

        </div>
        <table class="table text-center" id="table">

            <thead>
            <tr class="red">
                <th>#</th>
                <th>Name</th>
                <th>Email</th>
                <th>created date</th>
                
            </tr>
            </thead>
            <tbody>


                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key + 1); ?></td>
                        <td><?php echo e($data['name']); ?></td>

                        <td><?php echo e($data['email']); ?></td>
                        <td>  <?php echo e(Carbon\Carbon::parse($data->created_at)->format('d/m/Y H:i')); ?>   </td>

                        
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

        </table>
        
        <!-- /.box-body -->
    </div>
    <!-- /.box -->

</section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

    <script>
    $('#table').DataTable();
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>