@component('mail::message')
  <img src="{{asset('logo.png')}}">
  Hello  <strong> {{$name}} </strong> .
  <br>
  <br>
  Here is your email and password for the dashboard:
  <br>
  User: <strong> {{$email}} </strong>
  <br>
  {{--Password : <strong> {{$pass}} </strong>--}}
  <br>



  @component('mail::button', ['url' =>  route('login') ])
    Log in to Dashboard
  @endcomponent
  Kindly login to continue your process <br>
  Thanks,<br>

#  {{ config('app.name') }}
@endcomponent



