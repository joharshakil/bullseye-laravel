@extends('layouts.main')

@section('content')

    <section class="content-header">
        <h1>
            Services
            <!--small>it all starts here</small-->
        </h1>
    </section>



    <section class="content">

        <!-- Default box -->
        <div class="box-in">
            <ul>
           {{--     <li>
                    <a href="{{ route('es') }}" target="_blank" >ES Service</a></li>
            <li>  <a href="{{ route('cement') }}" target="_blank">CEMENT Service</a>   </li>
            <li>  <a href="{{ route('gpr') }}" target="_blank">GPR Service</a>   </li>--}}
            <!-- /.box-body -->
            </ul>
        </div>

        <!-- /.box -->

    </section>
@endsection
