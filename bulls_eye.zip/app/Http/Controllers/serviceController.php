<?php

namespace BullsEye\Http\Controllers;

use BullsEye\Em_service;
use BullsEye\Gpr_service;
use BullsEye\Cement_service;
use BullsEye\Mail\NewUserbyForm;
use BullsEye\Role;
use BullsEye\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Srmklive\PayPal\Services\ExpressCheckout;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Storage;
use BullsEye\Invoice;
use BullsEye\Employee;
use Carbon\Carbon;

class serviceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //

        return view('es');
    }

    public function adminProjects()
    {


    }


    public function projects()
    {
        if (Auth::id() == 2) //admin
        {
            $projects = Em_service::orderBy('created_at', 'desc')->paginate(10);
            return view('admin.projects', compact('projects'));
        } else
        {

            $em = Em_service::where('user_id', Auth::id())->orderBy('created_at', 'desc')->paginate(10);
            $cement = Cement_service::where('user_id', Auth::id())->orderBy('created_at', 'desc')->paginate(10);
            $gpr = Gpr_service::where('user_id', Auth::id())->orderBy('created_at', 'desc')->paginate(10);
            return view('member.projects', compact('em','cement','gpr'));

        }



    }



    public function projectCement()
    {
        if (Auth::id() == 2) //admin
        {
            $projects = Cement_service::orderBy('created_at', 'desc')->paginate(10);
        } else
            $projects = Cement_service::where('user_id', Auth::id())->orderBy('created_at', 'desc')->paginate(10);


        return view('member.projects-cement', compact('projects'));
    }

    public function projectGpr()
    {
        if (Auth::id() == 2) //admin
        {
            $projects = Gpr_service::orderBy('created_at', 'desc')->paginate(10);
        } else
            $projects = Gpr_service::where('user_id', Auth::id())->orderBy('created_at', 'desc')->paginate(10);


        return view('member.projects-gpr', compact('projects'));
    }

    /*    public function invoiceEs()
        {
            if (Auth::id() == 2) //admin
            {
                $invoice = em_service::orderBy('created_at', 'desc')->paginate(10);
            } else
                $invoice = em_service::where('user_id', Auth::id())->orderBy('created_at', 'desc')->paginate(10);


            return view('member.invoice-es', compact('$invoice'));
        }*/



    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        dd($request);
    }



    /*  protected function validator(Request $request)
      {
          return Validator::make($request, [
              'name' => 'required|string|max:255',
              'email' => 'required|string|email|max:255|unique:users',
              'password' => 'required|string|min:6|confirmed',
          ]);
      }*/
    public function save_service(Request $request)
    {
        if (Auth::check()) {
            /* $user = new \stdClass();*/

            $user = Auth::user();

            $user->id = Auth::id();
            /* $user->email = Auth::email();*/

        } else {
            // $pass = str_random(8);
            $rules = array(
                'email' => 'required|string|email|max:255|unique:users',
            );
            $user = array(
                'email' => $request->input('email'),
            );

//        dd($user);
            $validator = Validator::make($user, $rules);
            if ($validator->fails()) {

//        }
//            dd($validator);
                $message = 'That email address is already registered. You sure you don\'t have an account?';
                $code = 204;
                return response()->json($message, $code);

            } else {
                $new_user = [
                    'name' => $request->input('name'),
                    'email' => $request->input('email'),
                    'password' => bcrypt($request->input('password')),
                ];
                $user = User::create($new_user);
                $new_user['pass'] = $request->input('password');
                $user->roles()
                    ->attach(Role::where('name', 'member')->first());
            }
        }
        $service = new Em_service();
//        dd($request);
        $service->email = $user->email;
        /*  $service->email = $request->input('email');*/
          $checkpromocode  =  $request->input('promocode');

        if( $checkpromocode == "DIGDIRT") {
            $service->price = $request->input('price')  - 100 ;
           /* dd($checkpromocode)."aaa";*/

        }else{
            $service->price = $request->input('price');
          /*  dd($checkpromocode)."ssss";*/
        }


        //$service->price = $request->input('price');
        $filename =  $this->emservice($user->id,$user->name);
        $service->filename = $filename;
        $service->status = "Unschedule";
        $service->date = date('Y-m-d', strtotime($request->input('date')));
        $service->utility =  base64_encode(serialize($request->input('utility')));
        $service->location = $request->input('location');
        $service->billing_street = $request->input('billing_street');
        $service->province = $request->input('province');
         $service->zipcode = $request->input('zipcode');
          $service->city = $request->input('city');
         $service->country = $request->input('country');
        $service->markings = $request->input('markings');
        $service->needReport = $request->input('needReport');
          $service->job_street = $request->input('job_street');
          $service->job_city = $request->input('job_city');
         $service->job_province = $request->input('job_province');
        $service->job_zipcode = $request->input('job_zipcode');
        $service->description = $request->input('description');
        $service->distance = $request->input('distance');
        $service->promocode = $request->input('promocode');
        $service->user_name = $request->input('name');
        $service->newsletter = $request->input('newsletter');
        $service->company_name = $request->input('Companyname');
        $service->office_phone = $request->input('officePhone');
        $service->mobile_phone = $request->input('mobilePhone');
        $service->billing_location = $request->input('billinglocation');
        $service->city = $request->input('city');
        $service->province = $request->input('province');
        //  $service->scan_type = $request->input(' scan_type');
        $service->additional_information = $request->input('additionalinformation');
        $service->cross_Street = $request->input('crossStreet');
        $service->job_site_Contact_Name = $request->input('jobsiteContactNaame');
        $service->jobsite_Contact_Number = $request->input('jobsiteContactNumber');
        $service->user_id = $user->id;
        $path='';
        if($request->hasFile('image')) {
            foreach ($request->file('image') as $key => $image) {
                $validator = Validator::make(['image' => [$key => $image]], [
                    'image.0' => 'required|max:2048|image|mimes:jpg,jpeg,bmp,png|mimetypes:image/jpeg,image/bmp,image/png',
                ]);
                // if (!$validator->fails()) {
                $extension = $image->getClientOriginalExtension();
                $new_filename = uniqid('img_') . uniqid('', true) . time() . '.' . $extension  ;
                $path_tmp =  $image->storeAs('public/emfiles', $new_filename);
                $path .= $path_tmp."||";

                // }
            }
            $path = rtrim($path, '||');

            $service->image = $path;


        }


        $service->save();

       //  Mail::to($user->email)->cc('info@bullseyelocting.com')->send(new NewUserbyForm($new_user));
       // return response('status', 'Request generated successfuly, an eamil has been forwarded for further process');
//            Auth::loginUsingId($user->id);


        $code = 200;
        return response()->json($service, $code);
//                return redirect('/es/' . $service->id)->with('status', 'Request generated successfuly');

//            }

    }
    ///

//    }



    public function newUploading()
    {

        if (Auth::id() == 2) //admin
        {
            $em = Em_service::orderBy('created_at', 'desc')->paginate(10);
            $cement = Cement_service::orderBy('created_at', 'desc')->paginate(10);
            $gpr = Gpr_service::where('user_id', Auth::id())->orderBy('created_at', 'desc')->paginate(10);
            return view('file.view', compact('em','cement','gpr'));
        } else
        {

            $em = Em_service::where('user_id', Auth::id())->orderBy('created_at', 'desc')->paginate(10);
            $cement = Cement_service::where('user_id', Auth::id())->orderBy('created_at', 'desc')->paginate(10);
            $gpr = Gpr_service::where('user_id', Auth::id())->orderBy('created_at', 'desc')->paginate(10);
            return view('file.view', compact('em','cement','gpr'));

        }
    }
    public function gprform()
    {
        //

        return view('gpr');
    }

    public function cementform()
    {
        //

        return view('cement');
    }


    public function save_gpr_service(Request $request)
    {

//



        if (Auth::check()) {
            /* $user = new \stdClass();*/

            $user = Auth::user();

            $user->id = Auth::id();
            /* $user->email = Auth::email();*/

        } else {
            // $pass = str_random(8);
            $rules = array(
                'email' => 'required|string|email|max:255|unique:users',
            );
            $user = array(
                'email' => $request->input('email'),
            );

//        dd($user);
            $validator = Validator::make($user, $rules);
            if ($validator->fails()) {

//        }
//            dd($validator);
                $message = 'That email address is already registered. You sure you don\'t have an account?';
                $code = 204;
                return response()->json($message, $code);

            } else {
                $new_user = [
                    'name' => $request->input('name'),
                    'email' => $request->input('email'),
                    'password' => bcrypt($request->input('password')),
                ];
                $user = User::create($new_user);
                $new_user['pass'] = $request->input('password');
                $user->roles()
                    ->attach(Role::where('name', 'member')->first());
            }
        }

        $service = new Gpr_service();
        $filename =  $this->gprservice($user->id,$user->name);
        $service->filename = $filename;
        $service->user_id = $user->id;
        $service->email = $user->email;
        $service->status = "Unschedule";
        $service->price = $request->input('price');
        $service->country = $request->input('country');
        $service->marking = $request->input('marking');
        $service->utility_name = $request->input('utility_name');
        $service->location = $request->input('location');
         $service->billing_location = $request->input('billinglocation');
       /* $service->information = serialize($request->input('information'));*/
        $service->information  =  base64_encode(serialize($request->input('information')));
        $service->utility  =  base64_encode(serialize($request->input('utility')));
        $service->terrain  =  base64_encode(serialize($request->input('terrain')));
        $service->report  =  base64_encode(serialize($request->input('report')));

        /* $service->fiber = $request->input('fiber');*/
        $service->dimension = $request->input('dimension');
        $service->clean = $request->input('clean');
        $service->billing_street = $request->input('billing_street');
        $service->province = $request->input('province');
        $service->zipcode = $request->input('zipcode');
        $service->city = $request->input('city');
        $service->office_phone = $request->input('officePhone');
        $service->mobile_phone = $request->input('mobilePhone');
        $service->job_street = $request->input('job_street');
        $service->job_province = $request->input('job_province');
        $service->job_zipcode = $request->input('job_zipcode');
        $service->job_city = $request->input('job_city');
        $service->marking = $request->input('markings');
        $service->newsletter = $request->input('newsletter');
        $service->concrete = $request->input('concrete');
        $service->condition = $request->input('condition');
        $service->surface = $request->input('surface');
        $service->drawings = $request->input('drawings');
        $service->about_property = $request->input('about_property');
        $service->scan = $request->input('scan');
        $service->deep = $request->input('deep');
        $service->line_scan = $request->input('line_scan');
      /*  $service->terrain = serialize($request->input('terrain'));*/
        $service->report = serialize($request->input('report'));
        /*  $service->delivery_date = $request->input('delivery_date');*/
        $service->delivery_date = date('Y-m-d', strtotime($request->input('delivery_date')));



        $path='';
        if($request->hasFile('image')) {
            foreach ($request->file('image') as $key => $image) {
                $validator = Validator::make(['image' => [$key => $image]], [
                    'image.0' => 'required|max:2048|image|mimes:jpg,jpeg,bmp,png|mimetypes:image/jpeg,image/bmp,image/png',
                ]);
            // if (!$validator->fails()) {
                    $extension = $image->getClientOriginalExtension();
                    $new_filename = uniqid('img_') . uniqid('', true) . time() . '.' . $extension  ;
                    $path_tmp =  $image->storeAs('public/grpfiles', $new_filename);
                    $path .= $path_tmp."||";

               // }
            }
            $path = rtrim($path, '||');

            $service->image = $path;


        }


        /*if ($request->input('image')) {
              $image = $request->file('image');
              $name = str_slug($image->getClientOriginalName()) . '.' . $image->getClientOriginalExtension();
              $destinationPath = public_path('storage/grpfiles');
              $imagePath = $destinationPath . "/" . $name;
              $image->move($destinationPath, $imagePath);
              $service->image = (string)$imagePath;
          }*/




          /* dd($service);*/

     /*  if($request->input('image'))
        {

            foreach($request->File('image') as $image)
            {
                $name=$image->getClientOriginalName();
                $image->move(public_path().'storage');
                $data[] = $name;
            }
        }*/

        //$service->image= $request->input('image');

        $service->save();



        //  Mail::to($user->email)->cc('info@bullseyelocting.com')->send(new NewUserbyForm($new_user));
        //   return response('status', 'Request generated successfuly, an eamil has been forwarded for further process');
//            Auth::loginUsingId($user->id);


        $code = 200;
        return response()->json($service, $code);
//                return redirect('/es/' . $service->id)->with('status', 'Request generated successfuly');


        /*       if (!Auth::user()) {
   //            Mail::to($service->email)->cc('info@bullseyelocting.com')->send(new NewUserbyForm($new_user));
   //            return response('status', 'Request generated successfuly, an eamil has been forwarded for further process');
                   Auth::loginUsingId($user->id);
                   $code = 200;
                   return response()->json($service, $code);
               } else {
                   $code = 200;
                   return response()->json($service, $code);
   //            return redirect('/gpr/'.$service->id)->with('status', 'Request generated successfuly');

               }*/

    }
//    }







    public function save_cement_service(Request $request)
    {

        if (Auth::check()) {
            /* $user = new \stdClass();*/

            $user = Auth::user();

            $user->id = Auth::id();
            /* $user->email = Auth::email();*/

        } else {
            // $pass = str_random(8);
            $rules = array(
                'email' => 'required|string|email|max:255|unique:users',
            );
            $user = array(
                'email' => $request->input('email'),
            );

//        dd($user);
            $validator = Validator::make($user, $rules);
            if ($validator->fails()) {

//        }
//            dd($validator);
                $message = 'That email address is already registered. You sure you don\'t have an account?';
                $code = 204;
                return response()->json($message, $code);

            } else {
                $new_user = [
                    'name' => $request->input('name'),
                    'email' => $request->input('email'),
                    'password' => bcrypt($request->input('password')),
                ];
                $user = User::create($new_user);
                $new_user['pass'] = $request->input('password');
                $user->roles()
                    ->attach(Role::where('name', 'member')->first());
            }
        }



        $service = new Cement_service();
        $filename =  $this->cementservice($user->id,$user->name);
        $service->filename = $filename;
        $service->user_id = $user->id;

        $service->email = $user->email;
        $service->status = "Unschedule";
         $service->price = $request->input('price');
         $service->country = $request->input('country');
        $service->marking = $request->input('marking');
        $service->item  =  base64_encode(serialize($request->input('item')));
        $service->located  =  base64_encode(serialize($request->input('located')));
        $service->terrain  =  base64_encode(serialize($request->input('terrain')));
        /*$service->item = serialize($request->input('item'));*/
        $service->utility_name = $request->input('utility_name');
        $service->location = $request->input('location');
        $service->billing_location = $request->input('billinglocation');
        $service->scan = $request->input('scan');
        $service->slab = $request->input('slab');
        $service->distance = $request->input('distance');
        $service->billing_street = $request->input('billing_street');
        $service->province = $request->input('province');
        $service->zipcode = $request->input('zipcode');
        $service->city = $request->input('city');
        $service->office_phone = $request->input('officePhone');
        $service->mobile_phone = $request->input('mobilePhone');
        $service->job_street = $request->input('job_street');
        $service->job_province = $request->input('job_province');
        $service->job_zipcode = $request->input('job_zipcode');
        $service->job_city = $request->input('job_city');
        $service->report  =  base64_encode(serialize($request->input('report')));
      /*  $service->report = serialize($request->input('report'));*/
        $service->fiber = $request->input('fiber');
        $service->condition = $request->input('condition');
        $service->clean = $request->input('clean');
        $service->newsletter = $request->input('newsletter');
        $service->surface = $request->input('surface');
        $service->message = $request->input('message');
        $service->drawings = $request->input('drawings');
        $service->delivery_date = date('Y-m-d', strtotime($request->input('delivery_date')));
        /*       $service->delivery_date = $request->input('delivery_date');*/
        $service->about_property = $request->input('about_property');
       /* if ($request->hasFile('image')) {
            $image = $request->file('image');
            $name = str_slug($request->getClientOriginalName()) . '.' . $image->getClientOriginalExtension();
            $destinationPath = public_path('storage/grpfiles');
            $imagePath = $destinationPath . "/" . $name;
            $image->move($destinationPath, $imagePath);
            $service->image = (string)$imagePath;
        }*/

       /* $data=[];
        /*  dd($request->image);*/
        /*  if($request->hasfile('image'))
          {

              foreach($request->file('image') as $image)
              {
                  $name=$image->getClientOriginalName();
                  $image->move(public_path().'/images/', $name);
                  $data[] = $name;
              }
          }

          $service->image=json_encode($data);*/


        $path='';
        if($request->hasFile('image')) {
            foreach ($request->file('image') as $key => $image) {
                $validator = Validator::make(['image' => [$key => $image]], [
                    'image.0' => 'required|max:2048|image|mimes:jpg,jpeg,bmp,png|mimetypes:image/jpeg,image/bmp,image/png',
                ]);
                // if (!$validator->fails()) {
                $extension = $image->getClientOriginalExtension();
                $new_filename = uniqid('img_') . uniqid('', true) . time() . '.' . $extension  ;
                $path_tmp =  $image->storeAs('public/cementfiles', $new_filename);
                $path .= $path_tmp."||";

                // }
            }
            $path = rtrim($path, '||');

            $service->image = $path;


        }

        $service->save();

       // dd($request->all());
        //Mail::to($user->email)->cc('info@bullseyelocting.com')->send(new NewUserbyForm($new_user));
        //  return response('status', 'Request generated successfuly, an eamil has been forwarded for further process');
//            Auth::loginUsingId($user->id);


        $code = 200;
        return response()->json($service, $code);
//                return redirect('/es/' . $service->id)->with('status', 'Request generated successfuly');


        /* if (!Auth::user()) {
//            Mail::to($service->email)->cc('info@bullseyelocting.com')->send(new NewUserbyForm($new_user));
//            return response('status', 'Request generated successfuly, an eamil has been forwarded for further process');
             Auth::loginUsingId($user->id);
             $code = 200;
             return response()->json($service, $code);
         } else {
//            $code = 200;
//            return response()->json($service, $code);
             return redirect('/cement/' . $service->id)->with('status', 'Request generated successfuly');

         }*/
    }
//    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $em = Em_service::findOrFail($id);
        $utility = unserialize(base64_decode($em->utility));
        $data = Em_service::where('id', $id)->first();
        $datavalue  = explode("||",$data->image);
        $invoices = Invoice::where('service_id',$id)->where('service_title','em_service')->first();
        if (isset($invoices)) {
            $data->status = $invoices->payment_status;
        }
//        dd($invoice->payment_status);
      /*  if(isset($invoices)) {
            if ($invoices->payment_status == 'Completed') {
                $data->status = 'Completed';
            } else {
                $data->status = 'Pending';
            }
        }*/
        $docs = DB::table('uploads')
            ->Join('files', 'uploads.file_id', '=', 'files.id')
            ->where('files.em_project', $id)
            ->select('files.*', 'uploads.filename')
            ->orderBy('created_at', 'desc')
            ->paginate(1000);
//            dd($invoice);
      //  dd($data->utility);


        return view('member.es_view', compact('data', 'docs', 'em','invoices','datavalue','utility'));
    }

    public function showCementFormDetail($id)
    {
        //
        $em = Cement_service::findOrFail($id);
        $item = unserialize(base64_decode($em->item));
        $report = unserialize(base64_decode($em->report));
        $utility = unserialize(base64_decode($em->terrain));
        $located = unserialize(base64_decode($em->located));
        $data = Cement_service::where('id', $id)->first();

        $datavalue  = explode("||",$data->image);

        $data = Cement_service::where('id', $id)->first();
        $invoice = Invoice::where('service_id',$id)->where('service_title','cement_service')->first();
      if (isset($invoice)) {
          $data->status = $invoice->payment_status;
      }
//        dd($invoice->payment_status);
     /*   if(isset($invoice)) {
            if ($invoice->payment_status == 'Completed') {
                $data->status = 'Completed';
            } else {
                $data->status = 'Pending';
            }
        }*/
        $docs = DB::table('uploads')
            ->Join('files', 'uploads.file_id', '=', 'files.id')
            ->where('files.cement_project', $id)
            ->select('files.*', 'uploads.filename')
            ->orderBy('created_at', 'desc')
            ->paginate(10);
        return view('member.cement_view', compact('data', 'docs', 'em','invoice','datavalue','item','report','utility','located'));
    }




    public function emCancel($id)
    {

       $data = Em_service::where('id', $id)->first();



        $invoice = Invoice::where('service_id',$id)->where('service_title','em_service')->first();

        //$invoice_id = $invoice->id;
           // dd( $invoice_id);

//        dd($invoice->payment_status);
        if(isset($invoice)) {
            if ($invoice->payment_status == 'Completed') {
                return redirect()->route('services.es.show',[$data->id])->with('success', 'Your Invoice Is Completed It Can not be cancelled');

            } elseif ($invoice->payment_status == 'pending') {
               $invoice->payment_status = 'cancel';
                $invoice->save();
                return redirect()->route('services.es.show',[$data->id])->with('success', 'Your Invoice Is Successfully  cancelled');

            }else{
                return redirect()->route('services.es.show',[$data->id])->with('success', 'Your Invoice Is already cancelled');

            }
        }else{

            return redirect()->route('services.es.show',[$data->id])->with('success', 'No Invoice Found');
        }




    }

    public function cementCancel($id)
    {

        $data = Cement_service::where('id', $id)->first();



        $invoice = Invoice::where('service_id',$id)->where('service_title','cement_service')->first();
     //   dd($invoice);

        if(isset($invoice)) {
            if ($invoice->payment_status == 'Completed') {
                return redirect()->route('services.cement.show',[$data->id])->with('success', 'Your Invoice Is Completed It Can not be cancelled');

            } elseif ($invoice->payment_status == 'pending') {
                $invoice->payment_status = 'cancel';
                $invoice->save();
                return redirect()->route('services.cement.show',[$data->id])->with('success', 'Your Invoice Is Successfully  cancelled');

            }else{
                return redirect()->route('services.cement.show',[$data->id])->with('success', 'Your Invoice Is already cancelled');

            }
        }else{

            return redirect()->route('services.cement.show',[$data->id])->with('success', 'No Invoice Found');
        }

    }

    public function gprCancel($id)
    {

        $data = Gpr_service::where('id', $id)->first();



        $invoice = Invoice::where('service_id',$id)->where('service_title','gpr_service')->first();

        if(isset($invoice)) {
            if ($invoice->payment_status == 'Completed') {
                return redirect()->route('services.gpr.show',[$data->id])->with('success', 'Your Invoice Is Completed It Can not be cancelled');

            } elseif ($invoice->payment_status == 'pending') {
                $invoice->payment_status = 'cancel';
                $invoice->save();
                return redirect()->route('services.gpr.show',[$data->id])->with('success', 'Your Invoice Is Successfully  cancelled');

            }else{
                return redirect()->route('services.gpr.show',[$data->id])->with('success', 'Your Invoice Is already cancelled');

            }
        }
        else{

            return redirect()->route('services.es.show',[$data->id])->with('success', 'No Invoice Found');
        }




    }
    public function gprservice($userid,$username)
    {
      $filename = "terms-and-condition-".$userid."-".time().".pdf";
       //$data = Gpr_service::all();
        $pdf = \PDF::loadView('admin.gpr_service',['name'=>$username,"date"=>date('m/d/Y')]);
          $pdf->save(storage_path('app/public/'.$filename));
        return $filename;
       // return view('admin.gpr_service', compact('data'));
    }
    public function emservice($userid,$username)
    {
        $filename = "terms-and-condition-".$userid."-".time().".pdf";
        //$data = Gpr_service::all();
        $pdf = \PDF::loadView('admin.em_service',['name'=>$username,"date"=>date('m/d/Y')]);
        $pdf->save(storage_path('app/public/'.$filename));
        return $filename;
        // return view('admin.gpr_service', compact('data'));
    }
    public function cementservice($userid,$username)
    {
        $filename = "terms-and-condition-".$userid."-".time().".pdf";
        //$data = Gpr_service::all();
        $pdf = \PDF::loadView('admin.cement_service',['name'=>$username,"date"=>date('m/d/Y')]);
        $pdf->save(storage_path('app/public/'.$filename));
        return $filename;
        // return view('admin.gpr_service', compact('data'));
    }


    public function showGprFormDetail($id)
    {
        $em = Gpr_service::findOrFail($id);
        $data = Gpr_service::where('id', $id)->first();

        $information = unserialize(base64_decode($em->information));
        $report = unserialize(base64_decode($em->report));
        $terrain = unserialize(base64_decode($em->terrain));
        $utility = unserialize(base64_decode($em->utility));
        $datavalue  = explode("||",$data->image);

    /*    $datavalue = preg_replace_callback( '!s:(\d+):"(.*?)";!', function($match) {
              return ($match[1] == strlen($match[2])) ? $match[0] : 's:' . strlen($match[2]) . ':"' . $match[2] . '";';
          },$data->image );*/

   /*     $data = preg_replace_callback(
            '/(?<=^|\{|;)s:(\d+):\"(.*?)\";(?=[asbdiO]\:\d|N;|\}|$)/s',
            function($m){
                return 's:' . mb_strlen($m[2]) . ':"' . $m[2] . '";';
            },
            $data->image
        );*/

        $data = Gpr_service::where('id', $id)->first();
        $invoice = Invoice::where('service_id',$id)->where('service_title','gpr_service')->first();
        if (isset($invoice)) {
            $data->status = $invoice->payment_status;
        }





        /*$invoice = Invoice::where('service_id',$id)->where('service_title','gpr_service')->first();
//        dd($invoice->payment_status);
        if(isset($invoice)) {
            if ($invoice->payment_status == 'Completed') {
                $data->status = 'Completed';
            } else {
                $data->status = 'Pending';
            }
        }*/
        $docs = DB::table('uploads')
            ->Join('files', 'uploads.file_id', '=', 'files.id')
            ->where('files.gpr_project', $id)
            ->select('files.*', 'uploads.filename')
            ->orderBy('created_at', 'desc')
            ->paginate(10);


        return view('member.gpr_view', compact('data', 'docs', 'em','invoice','datavalue','information','terrain','report','utility'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    public function redirection($id)
    {
        $invoice = Invoice::find($id);
        if($invoice->service_title == 'em_service') {
            $service = Em_service::find($invoice->service_id);
        }if($invoice->service_title == 'gpr_service') {
        $service = Gpr_service::find($invoice->service_id);
    }if($invoice->service_title == 'cement_service') {
        $service = Cement_service::find($invoice->service_id);
    }
        $user = User::find($service->user_id);
        $user->delete();

        return redirect('/')->with('status', 'Request cancel');

    }

    public function emDelete($id)
    {

        $user = Em_service::find($id);

        if(isset($user)){
            $user->delete();

        }

        $invoice = Invoice::where('service_id', $id)->where('service_title', 'em_service')->first();
        if(isset($invoice)){
            $invoice->delete();

        }

        return redirect('appointment')->with('status', 'Request Has been Deleted');

    }
    public function cementDelete($id)
    {

        $user = Cement_service::find($id);

        if(isset($user)){
            $user->delete();

        }

        $invoice = Invoice::where('service_id', $id)->where('service_title', 'cement_service')->first();
        if(isset($invoice)){
            $invoice->delete();

        }

        return redirect('appointment')->with('status', 'Request Has been Deleted');

    }
    public function gprDelete($id)
    {

        $user = Gpr_service::find($id);

        if(isset($user)){
            $user->delete();

        }

        $invoice = Invoice::where('service_id', $id)->where('service_title', 'gpr_service')->first();
        if(isset($invoice)){
            $invoice->delete();

        }

        return redirect('appointment')->with('status', 'Request Has been Deleted');

    }



    public function get_employee()
    {
      $employee =  Employee::all();

        return view('admin.appointments.employeeview', compact('employee'));
    }

    public function editShow($id)
    {
        $data = Em_service::find($id);
        $employee =  Employee::all();

        return view('member.es_edit', compact('data','employee'));
    }

    public function editUpdate(Request $request, $id)
    {
        $service = Em_service::findOrFail($id);
       $invoice = Invoice::where('service_id',$id)->where('service_title','em_service')->first();

        if(isset($invoice)) {
            if ($invoice->payment_status == 'cancel') {
                $invoice->payment_status = 'pending';
                $invoice->save();
           }
        }
        if(Auth::id() == 2) {
            $service->status = $request->status;
            $service->employee_id = $request->employee;
            $service->starttime = $request->starttime;
            $service->endtime = $request->endtime;
        }

        $service->country = $request->country;
        $service->date = $request->date;
        $service->description = $request->description;
        $service->newsletter = $request->newsletter;
        $service->office_phone = $request->office_phone;
        $service->mobile_phone = $request->mobile_phone;
       /* $service->utility = $request->utility;*/
        $service->markings = $request->markings;
        $service->save();

        if (Auth::id() == 2){
            return redirect('appointment');
        }else {
            return redirect('user_projects');
        }
        //  Mail::to($user->email)->cc('info@bullseyelocting.com')->send(new NewUserbyForm($new_user));
        //   return response('status', 'Request generated successfuly, an eamil has been forwarded for further process');
//            Auth::loginUsingId($user->id);


       // $code = 200;
       // return response()->json($service, $code);
//                return redirect('/es/' . $service->id)->with('status', 'Request generated successfuly');

    }

    public function editgprShow($id)
    {
        $data = Gpr_service::find($id);
        $employee =  Employee::all();
        return view('member.gpr_edit', compact('data','employee'));
    }

    public function editgprUpdate(Request $request, $id)
    {
        $service = Gpr_service::findOrFail($id);
        $invoice = Invoice::where('service_id',$id)->where('service_title','gpr_service')->first();

        if(isset($invoice)) {
            if ($invoice->payment_status == 'cancel') {
                $invoice->payment_status = 'pending';
                $invoice->save();
            }
        }
        if(Auth::id() == 2) {
            $service->status = $request->status;
            $service->employee_id = $request->employee;
            $service->starttime = $request->starttime;
            $service->endtime = $request->endtime;
        }


        $service->country = $request->country;
        $service->delivery_date = $request->delivery_date;
    /*    $service->billing_street = $request->billing_street;*/
        $service->newsletter = $request->newsletter;
        $service->office_phone = $request->office_phone;
        $service->mobile_phone = $request->mobile_phone;
        /*$service->terrain = $request->terrain;*/
        $service->marking = $request->markings;
        $service->save();

        if (Auth::id() == 2){
            return redirect('appointments');
        }else {
            return redirect('user_projects');
        }
        //  Mail::to($user->email)->cc('info@bullseyelocting.com')->send(new NewUserbyForm($new_user));
        //   return response('status', 'Request generated successfuly, an eamil has been forwarded for further process');
//            Auth::loginUsingId($user->id);


        //$code = 200;
        //return response()->json($service, $code);
//                return redirect('/es/' . $service->id)->with('status', 'Request generated successfuly');

    }

    public function editcementShow($id)
    {
        $data = Cement_service::find($id);
        $employee =  Employee::all();
  return view('member.cement_edit', compact('data','employee'));
    }

    public function editcementUpdate(Request $request, $id)
    {
        $service = Cement_service::findOrFail($id);
        $invoice = Invoice::where('service_id',$id)->where('service_title','cement_service')->first();
        if(Auth::id() == 2) {
            $service->status = $request->status;
            $service->employee_id = $request->employee;
            $service->starttime = $request->starttime;
            $service->endtime = $request->endtime;
        }
        if(isset($invoice)) {
            if ($invoice->payment_status == 'cancel') {
                $invoice->payment_status = 'pending';
                $invoice->save();
            }
        }


        $service->country = $request->country;
        $service->delivery_date = $request->delivery_date;
     /*   $service->billing_street = $request->billing_street;*/
        $service->newsletter = $request->newsletter;
        $service->office_phone = $request->office_phone;
        $service->mobile_phone = $request->mobile_phone;
        /*$service->item = $request->item;*/
        $service->marking = $request->markings;
        $service->save();

        if (Auth::id() == 2){
            return redirect('appointment');
        }else {
            return redirect('user_projects');
        }

        //  Mail::to($user->email)->cc('info@bullseyelocting.com')->send(new NewUserbyForm($new_user));
        //   return response('status', 'Request generated successfuly, an eamil has been forwarded for further process');
//            Auth::loginUsingId($user->id);


       // $code = 200;
//                return redirect('/es/' . $service->id)->with('status', 'Request generated successfuly');
    }

    public function createEmloyee(Request $request)
    {

        $employee = new Employee();
      //
        $employee->employee_Name = $request->employee_name;
        $employee->job_type = $request->employee_type;
        $employee->phone_number  =  $request->phone_number;

        //dd($employee);
        $employee->save();

        return \Redirect::back();


    }
}
